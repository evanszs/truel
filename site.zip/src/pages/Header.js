import '../css/header.css'
import fundo from '../img/truelove.jpg'
const Header = () => {
  return (
  


    <div >
      <div>
      <h1 class="page-title">True love </h1>
    <header class="header bd"> 

     </header>


     </div></div>
  )
}

export default Header