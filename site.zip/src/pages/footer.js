import '../css/footer.css'

const Footer = () => {
  return (
    <footer>
01
<footer>
02
<nav>
03
<h2>Navegue no site</h2>
04
<ul>
05
<li><a href="#">Capa</a></li> 
06
<li><a href="#">História dos instrumentos de metal</a></li>
07
<li><a href="#">Seja um colaborarador</a></li>
08
<li><a href="#">Quem somos</a></li>
09
</ul>
10
</nav>
11
<nav>
12
<h2>Fique conectado !</h2>
13
<ul>
14
<li><a href="#">Email</a></li>
15
<li><a href="#">Twitter</a></li>
16
<li><a href="#">Youtube</a></li>
17
<li><a href="#">Facebook</a></li>
18
</ul>
19
</nav>
20
<small>Copyright © 2010 </small>
21
</footer>

  </footer>
  )
}

export default Footer