
import './App.css';
import Footer from './pages/footer';
import Header from './pages/Header';
import Meio from './pages/Meio';

function App() {
  return (
    <div className="App">

<Header></Header>
<Meio></Meio>

    </div>
  );
}

export default App;
